# This addon changes system level code for Kodi and may break Kodi.
# Use at your own risk.
# This addon requires python3 and will only work on kodi Matrix 19.0 or above