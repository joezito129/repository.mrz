# -*- coding: utf-8 -*-
from lib.Plugin import main

main() # See bottom of Plugin.py.