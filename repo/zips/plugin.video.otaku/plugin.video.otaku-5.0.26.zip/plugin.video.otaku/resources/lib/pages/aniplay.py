from resources.lib.ui.BrowserBase import BrowserBase


class sources(BrowserBase):

    def get_sources(self, anilist_id, episode):
        return []
