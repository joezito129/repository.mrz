import json
import random
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import sys
import os

from urllib import parse

try:
    HANDLE = int(sys.argv[1])
except IndexError:
    HANDLE = 0

addonInfo = xbmcaddon.Addon().getAddonInfo
ADDON_ID = addonInfo('id')
ADDON = xbmcaddon.Addon(ADDON_ID)
Settings = ADDON.getSettings()
lang = ADDON.getLocalizedString
addonInfo = ADDON.getAddonInfo
ADDON_NAME = addonInfo('name')
ADDON_VERSION = addonInfo('version')
ADDON_ICON = addonInfo('icon')
FANART = addonInfo('fanart')
ADDON_PATH = ADDON.getAddonInfo('path')
dataPath = xbmcvfs.translatePath(addonInfo('profile'))
# sys.path.append(dataPath)
kodi_version = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

cacheFile = os.path.join(dataPath, 'cache.db')
searchHistoryDB = os.path.join(dataPath, 'search.db')
malSyncDB = os.path.join(dataPath, 'malSync.db')
mappingDB = os.path.join(dataPath, 'mappings.db')

maldubFile = os.path.join(dataPath, 'mal_dub.json')
downloads_json = os.path.join(dataPath, 'downloads.json')
completed_json = os.path.join(dataPath, 'completed.json')

COMMON_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'common')
LOGO_SMALL = os.path.join(COMMON_PATH, 'trans-goku-small.png')
LOGO_MEDIUM = os.path.join(COMMON_PATH, 'trans-goku.png')
ICONS_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'icons', ADDON.getSetting("interface.icons"))

execute = xbmc.executebuiltin
progressDialog = xbmcgui.DialogProgress()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
window = xbmcgui.Window(10000)

bool_cache = {}


def get_bool_cache(setting_id: str):
    if setting_id not in bool_cache:
        bool_cache[setting_id] = getBool(setting_id)
    return bool_cache[setting_id]


def closeBusyDialog() -> None:
    if xbmc.getCondVisibility('Window.IsActive(busydialog)'):
        execute('Dialog.Close(busydialog)')
    if xbmc.getCondVisibility('Window.IsActive(busydialognocancel)'):
        execute('Dialog.Close(busydialognocancel)')


def log(msg, level="info") -> None:
    if level == 'info':
        level = xbmc.LOGINFO
    elif level == 'debug':
        level = xbmc.LOGDEBUG
    elif level == 'warning':
        level = xbmc.LOGWARNING
    elif level == 'error':
        level = xbmc.LOGERROR
    elif level == 'fatal':
        level = xbmc.LOGFATAL
        # SAVE THE KIDS THE PLANE IS GOING DOWN!!
    else:
        level = xbmc.LOGNONE
    xbmc.log(f'{ADDON_NAME.upper()} ({HANDLE}): {msg}', level)


def enabled_debrid() -> dict:
    debrids = ['real_debrid', 'debrid_link', 'alldebrid', 'premiumize', 'torbox']
    return {x: getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled') for x in debrids}


def enabled_watchlists() -> list:
    watchlists = ['mal', 'anilist', 'simkl', 'kitsu']
    return [x for x in watchlists if getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled')]


def watchlist_to_update() -> str:
    if getBool('watchlist.update.enabled'):
        flavor = getSetting('watchlist.update.flavor')
        if getBool(f"{flavor}.enabled"):
            return flavor
    return ''


def copy2clip(txt: str) -> bool:
    import subprocess
    platform = sys.platform
    log(platform)
    try:
        if platform == 'win32':
            process = subprocess.Popen(['clip'], stdin=subprocess.PIPE, text=True)
            process.communicate(input=txt)
            return True
        elif platform == 'darwin':  # macOS
            process = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE, text=True)
            process.communicate(input=txt)
            return True
        elif platform == 'linux':
            # Linux requires xclip or xsel to be installed
            process = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE, text=True)
            process.communicate(input=txt)
            return True
    except Exception as e:
        log(e)
    return False


def colorstr(text, color: str = 'deepskyblue') -> str:
    return f"[COLOR {color}]{text}[/COLOR]"


def refresh() -> None:
    execute('Container.Refresh')


def getSetting(key: str) -> str:
    cache = window.getProperty(f'{ADDON_ID}_{key}')
    return cache if cache else ADDON.getSetting(key)


def getBool(key: str) -> bool:
    cache = window.getProperty(f'{ADDON_ID}_{key}')
    return cache == 'true' if cache else Settings.getBool(key)


def getInt(key: str) -> int:
    cache = window.getProperty(f'{ADDON_ID}_{key}')
    return int(cache) if cache else Settings.getInt(key)


def getString(key: str) -> str:
    cache = window.getProperty(f'{ADDON_ID}_{key}')
    return cache if cache else Settings.getString(key)


def getStringList(settingid: str) -> list:
    return Settings.getStringList(settingid)


def setSetting(settingid: str, value: str) -> None:
    ADDON.setSetting(settingid, value)


def setBool(settingid: str, value: bool) -> None:
    Settings.setBool(settingid, value)


def setInt(settingid: str, value: int) -> None:
    Settings.setInt(settingid, value)


def setStringList(settingid: str, value: list):
    Settings.setStringList(settingid, value)


def addon_url(url: str) -> str:
    return f"plugin://{ADDON_ID}/{url}"


def get_plugin_url(url: str) -> str:
    addon_base = addon_url('')
    return url[len(addon_base):]


def get_plugin_params(param: str) -> dict:
    return dict(parse.parse_qsl(param.replace('?', '')))
    # return dict(item.split("=") for item in param.lstrip('?').split("&") if "=" in item)


def get_payload_params(url: str) -> tuple:
    url_list = url.rsplit('?', 1)
    if len(url_list) == 1:
        url_list.append('')
    payload, params = url_list
    return get_plugin_url(payload), get_plugin_params(params)


def exit_code() -> None:
    if getSetting('reuselanguageinvoker.status') == 'Enabled':
        sys.exit(1)


def keyboard(title: str, text: str = '') -> str:
    keyboard_ = xbmc.Keyboard(text, title, False)
    keyboard_.doModal()
    return keyboard_.getText() if keyboard_.isConfirmed() else ""


def closeAllDialogs() -> None:
    execute('Dialog.Close(all,true)')


def ok_dialog(title: str, text: str) -> bool:
    return xbmcgui.Dialog().ok(title, text)


def textviewer_dialog(title: str, text: str) -> None:
    xbmcgui.Dialog().textviewer(title, text)


def yesno_dialog(title: str, text: str, nolabel: str = '', yeslabel: str = '') -> bool:
    return xbmcgui.Dialog().yesno(title, text, nolabel, yeslabel)


def yesnocustom_dialog(title: str, text: str, customlabel: str = '', nolabel: str = '', yeslabel: str = '', autoclose: int = 0, defaultbutton: int = 0) -> int:
    return xbmcgui.Dialog().yesnocustom(title, text, customlabel, nolabel, yeslabel, autoclose, defaultbutton)


def notify(title: str, text: str, icon: str = LOGO_MEDIUM, time: int = 5000, sound: bool = True) -> None:
    xbmcgui.Dialog().notification(title, text, icon, time, sound)


def input_dialog(title: str, input_: str = '', option: int = 0) -> str:
    return xbmcgui.Dialog().input(title, input_, option=option)


def multiselect_dialog(title: str, dialog_list: list) -> list:
    return xbmcgui.Dialog().multiselect(title, dialog_list)


def select_dialog(title: str, dialog_list: list) -> int:
    return xbmcgui.Dialog().select(title, dialog_list)


def context_menu(context_list: list) -> int:
    return xbmcgui.Dialog().contextmenu(context_list)


def browse(type_: int, heading: str, shares: str, mask: str = '') -> str:
    return xbmcgui.Dialog().browse(type_, heading, shares, mask)


def handle_set_fanart(art: dict, info: dict) -> dict:
    if not art.get('fanart') or get_bool_cache('interface.fanart.disable'):
        art['fanart'] = FANART
    else:
        if isinstance(art['fanart'], list):
            if get_bool_cache('context.otaku.fanartselect'):
                if info.get('UniqueIDs', {}).get('mal_id'):
                    fanart_select = getSetting(f'fanart.select.{info["UniqueIDs"]["mal_id"]}')
                    art['fanart'] = fanart_select if fanart_select else random.choice(art['fanart'])
                else:
                    art['fanart'] = FANART
            else:
                art['fanart'] = random.choice(art['fanart'])
    return art


def set_videotags(li: xbmcgui.ListItem, info: dict) -> None:
    vinfo: xbmc.InfoTagVideo = li.getVideoInfoTag()
    if title := info.get('title'):
        vinfo.setTitle(title)
    if media_type := info.get('mediatype'):
        vinfo.setMediaType(media_type)
    if tvshow_title := info.get('tvshowtitle'):
        vinfo.setTvShowTitle(tvshow_title)
    if plot := info.get('plot'):
        vinfo.setPlot(plot)
    if year := info.get('year'):
        vinfo.setYear(int(year))
    if premiered := info.get('premiered'):
        vinfo.setPremiered(premiered)
    if status := info.get('status'):
        vinfo.setTvShowStatus(status)
    if genre := info.get('genre'):
        vinfo.setGenres(genre)
    if mpaa := info.get('mpaa'):
        vinfo.setMpaa(mpaa)
    if rating := info.get('rating'):
        vinfo.setRating(rating.get('score', 0), rating.get('votes', 0))
    if season := info.get('season'):
        vinfo.setSeason(int(season))
    if episode := info.get('episode'):
        vinfo.setEpisode(int(episode))
    if aired := info.get('aired'):
        vinfo.setFirstAired(aired)
    if playcount := info.get('playcount'):
        vinfo.setPlaycount(playcount)
    if duration := info.get('duration'):
        vinfo.setDuration(duration)
    if code := info.get('code'):
        vinfo.setProductionCode(code)
    if studio := info.get('studio'):
        vinfo.setStudios(studio)
    if cast := info.get('cast'):
        vinfo.setCast([xbmc.Actor(c['name'], c['role'], c['index'], c['thumbnail']) for c in cast])
    if originaltitle := info.get('OriginalTitle'):
        vinfo.setOriginalTitle(originaltitle)
    if trailer := info.get('trailer'):
        vinfo.setTrailer(trailer)
    if uniqueids := info.get('UniqueIDs'):
        vinfo.setUniqueIDs(uniqueids)
    if resume := info.get('resume'):
        vinfo.setResumePoint(float(resume), 1)
    if properties := info.get('properties'):
        li.setProperties(properties)


def jsonrpc(json_data: dict) -> dict:
    return json.loads(xbmc.executeJSONRPC(json.dumps(json_data)))


def xbmc_add_dir(name: str, url: str, art, info: dict, draw_cm: list, isfolder: bool, isplayable: bool) -> tuple:
    u = addon_url(url)
    liz = xbmcgui.ListItem(name, offscreen=True)
    if info:
        set_videotags(liz, info)
    if draw_cm:
        cm = [(x[0], f'RunPlugin(plugin://{ADDON_ID}/{x[1]}/{url})') for x in draw_cm]
        liz.addContextMenuItems(cm)

    art = handle_set_fanart(art, info)

    if get_bool_cache('interface.clearlogo.disable'):
        art['clearlogo'] = ICONS_PATH
    if isplayable:
        art['tvshow.poster'] = art.pop('poster')
        liz.setProperties({'Video': 'true', 'IsPlayable': 'true'})
    liz.setArt(art)
    return u, liz, isfolder


def bulk_draw_items(video_data: list) -> bool:
    list_items = bulk_dir_list(video_data)
    return xbmcplugin.addDirectoryItems(HANDLE, list_items)


def draw_items(video_data: list, content_type: str = '') -> None:
    bulk_draw_items(video_data)
    if content_type:
        xbmcplugin.setContent(HANDLE, content_type)
    if content_type == 'episodes':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE, "%H. %T", "%R | %P")
    elif content_type == 'tvshows':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE, "%L", "%R")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    if getBool('interface.viewtypes.bool'):
        xbmc.sleep(100)
        if content_type == 'tvshows':
            xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.viewtypes.tvshows')))
        elif content_type == 'episodes':
            xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.viewtypes.episodes')))
        else:
            xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.viewtypes.general')))

    # move to episode position currently watching
    if content_type == "episodes" and getBool('general.smart.scroll.enable'):
        for _ in range(15):
            if xbmc.getCondVisibility("Container.HasFiles"):
                break
            xbmc.sleep(50)
        try:
            num_watched = int(xbmc.getInfoLabel("Container.TotalWatched"))
            total_ep = int(xbmc.getInfoLabel('Container(id).NumItems'))
            total_items = int(xbmc.getInfoLabel('Container(id).NumAllItems'))
            if total_items == total_ep + 1:
                num_watched += 1
                total_ep += 1
        except ValueError:
            return
        if total_ep > num_watched > 0:
            xbmc.executebuiltin('Action(firstpage)')
            for _ in range(num_watched):
                xbmc.executebuiltin('Action(Down)')


def bulk_dir_list(video_data: list) -> list:
    return [xbmc_add_dir(vid['name'], vid['url'], vid['image'], vid['info'], vid['cm'], vid['isfolder'], vid['isplayable']) for vid in video_data if vid]


def get_view_type(viewtype: str) -> int:
    viewTypes = {
        'Default': 50,
        'Poster': 51,
        'Icon Wall': 52,
        'Shift': 53,
        'Info Wall': 54,
        'Wide List': 55,
        'Wall': 500,
        'Banner': 501,
        'Fanart': 502,
        'List': 0
    }
    return viewTypes[viewtype]

def is_addon_visible() -> bool:
    return xbmc.getInfoLabel('Container.PluginName') == 'plugin.video.otaku'


def is_video_window_open():
    return False if xbmcgui.getCurrentWindowId() != 12005 else True


def json_res(response):
    try:
        response = response.json()
    except:
        response = {}
    return response


def print(string, *args) -> None:
    for i in list(args):
        string = f'{string} {i}'
    textviewer_dialog('print', f'{string}')
    del args, string

def timeIt(func):
    # Thanks to 123Venom
    import time
    def wrap(*args, **kwargs):
        started_at = time.perf_counter()
        result = func(*args, **kwargs)
        log(f">> {__name__}.{func.__name__} <<: {time.perf_counter() - started_at}")
        return result
    return wrap
