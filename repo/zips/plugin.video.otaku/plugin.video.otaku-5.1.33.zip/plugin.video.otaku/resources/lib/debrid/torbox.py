import requests
import xbmc

from resources.lib.ui import source_utils, control


class Torbox:
    def __init__(self):
        self.token = control.getString('torbox.token')
        self.BaseUrl = "https://api.torbox.app/v1/api"
        self.dialog = None

    def headers(self):
        return {'Authorization': f"Bearer {self.token}"}

    def auth(self) -> None:
        from resources.lib.windows.progress_dialog import Progress_dialog
        import pyqrcode
        import os
        params = {'app': control.ADDON_NAME}
        r = requests.get(f'{self.BaseUrl}/user/auth/device/start', params=params)
        if r.ok:
            res = control.json_res(r).get('data')
            if res:
                device_code = res.get('device_code', '')
                user_code = res.get('code', '')
                verification_url = res.get('friendly_verification_url') or res.get('verification_url', 'https://tor.box/link')

                copied = control.copy2clip(user_code)
                display_dialog = (f"{control.lang(30020).format(control.colorstr(verification_url))}[CR]"
                                  f"{control.lang(30021).format(control.colorstr(user_code))}")
                if copied:
                    display_dialog = f"{display_dialog}[CR]{control.lang(30022)}"

                qr_path = os.path.join(control.dataPath, 'qr_code.png')
                qr = pyqrcode.create(verification_url)
                qr.png(qr_path, scale=20)
                config = {
                    'heading': f'{control.ADDON_NAME}: TorBox Auth',
                    'text': display_dialog,
                    'image': qr_path,
                    'percent': 100
                }
                self.dialog = Progress_dialog('progress_dialog.xml', control.ADDON_PATH, config=config)
                self.dialog.show()

                OauthTotalTimeout = res.get('expires_at', '')
                OauthTimeStep = int(res.get('interval', 5))
                OauthTotalTimeout = OauthTimeout = 600

                data = {'device_code': device_code}
                auth_done = False
                while not auth_done and OauthTimeout > 0:
                    OauthTimeout -= OauthTimeStep
                    xbmc.sleep(OauthTimeStep * 1000)
                    auth_done, expires_in = self.auth_loop(data, OauthTimeout)
                    self.dialog.update(int(OauthTimeout / OauthTotalTimeout * 100))
                self.dialog.close()
                if auth_done:
                    self.status()


    def auth_loop(self, data, timeout) -> tuple:
        if self.dialog.iscanceled():
            timeout = 0
            return False, timeout
        r = requests.post(f'{self.BaseUrl}/user/auth/device/token', json=data)
        if r.ok:
            r = control.json_res(r)
            res = r.get('data')
            if 'access_token' in res:
                self.token = res['access_token']
                control.setString('torbox.token', self.token)
                return True, timeout
        return False, timeout


    def status(self) -> bool:
        r = requests.get(f'{self.BaseUrl}/user/me', headers=self.headers())
        if r.ok:
            user_info = r.json()['data']
            control.setString('torbox.username', user_info['email'])
            if user_info['plan'] == 0:
                control.setString('torbox.auth.status', 'Free')
                control.ok_dialog(f'{control.ADDON_NAME}: Torbox', control.lang(30024))
            elif user_info['plan'] == 1:
                control.setString('torbox.auth.status', 'Essential')
            elif user_info['plan'] == 3:
                control.setString('torbox.auth.status', 'Standard')
            elif user_info['plan'] == 2:
                control.setString('torbox.auth.status', 'Pro')
            control.ok_dialog(control.ADDON_NAME, 'Torbox %s' % control.lang(30023))
        return r.ok

    def refreshToken(self):
        url = f'{self.BaseUrl}/v1/api/user/refreshtoken'
        r = requests.post(url, headers=self.headers())
        return r.ok

    def hash_check(self, hash_list: list) -> dict:
        hashes = ','.join(hash_list)
        url = f'{self.BaseUrl}/torrents/checkcached'
        params = {
            'hash': hashes,
            'format': 'list'
        }
        r = requests.get(url, headers=self.headers(), params=params)
        return r.json()['data']

    def addMagnet(self, magnet: str) -> dict:
        url = f'{self.BaseUrl}/torrents/createtorrent'
        data = {
            'magnet': magnet
        }
        r = requests.post(url, headers=self.headers(), data=data)
        return r.json()['data']

    def delete_torrent(self, torrent_id) -> bool:
        url = f'{self.BaseUrl}/torrents/controltorrent'
        data = {
            'torrent_id': str(torrent_id),
            'operation': 'delete'
        }
        r = requests.post(url, headers=self.headers(), json=data)
        return r.ok

    def list_torrents(self) -> dict:
        url = f'{self.BaseUrl}/torrents/mylist'
        r = requests.get(url, headers=self.headers())
        return r.json()['data']

    def get_torrent_info(self, torrent_id: str, bypass_cache=False):
        url = f'{self.BaseUrl}/torrents/mylist'
        params = {'id': torrent_id}
        if bypass_cache:
            params['bypass_cache'] = 'true'
        r = requests.get(url, headers=self.headers(), params=params)
        return r.json()['data']

    def request_dl_link(self, torrent_id, file_id=-1):
        url = f'{self.BaseUrl}/torrents/requestdl'
        params = {
            'token': self.token,
            'torrent_id': torrent_id
        }
        if file_id >= 0:
            params['file_id'] = file_id
        r = requests.get(url, params=params)
        return r.json()['data']

    def resolve_single_magnet(self, hash_, magnet, episode, pack_select, filename):
        torrent = self.addMagnet(magnet)
        torrentId = torrent['torrent_id']
        torrent_info = self.get_torrent_info(torrentId)
        folder_details = [{'fileId': x['id'], 'path': x['name']} for x in torrent_info['files']]
        if episode:
            selected_file = source_utils.get_best_match('path', folder_details, str(episode), pack_select, filename)
            if selected_file and selected_file.get('fileId') is not None:
                stream_link = self.request_dl_link(torrentId, selected_file['fileId'])
                self.delete_torrent(torrentId)
                return stream_link
        self.delete_torrent(torrentId)
        return None

    def resolve_hoster(self, source):
        return self.request_dl_link(source['folder_id'], source['file']['id'])

    @staticmethod
    def resolve_cloud(source, pack_select):
        match = {}
        if source['hash']:
            best_match = source_utils.get_best_match('short_name', source['hash'], source['episode'], pack_select)
            if best_match and best_match.get('short_name'):
                for f_index, torrent_file in enumerate(source['hash']):
                    if torrent_file['short_name'].removeprefix('[CR]').strip() == best_match['short_name']:
                        match = {'folder_id': source['id'], 'file': source['hash'][f_index]}
                        break
        return match


    def resolve_uncached_source_background(self, source, autorun):
        heading = f'{control.ADDON_NAME}: Cache Resolver'
        torrent = self.addMagnet(source['magnet'])
        torrent_info = self.get_torrent_info(torrent['torrent_id'])
        control.ok_dialog(heading, f"{torrent_info['name']} has been added to your Torbox")


    def resolve_uncached_source_forground(self, source, autorun):
        heading = f'{control.ADDON_NAME}: Cache Resolver'
        control.progressDialog.create(heading, "Caching Progress")
        torrent = self.addMagnet(source['magnet'])
        torrent_id = torrent['torrent_id']
        torrent = self.get_torrent_info(torrent_id, bypass_cache=True)
        monitor = xbmc.Monitor()
        while not torrent['download_finished']:
            if control.progressDialog.iscanceled() or monitor.waitForAbort(5):
                break
            torrent = self.get_torrent_info(torrent_id, bypass_cache=True)
            if not torrent:
                break
            if torrent['download_state'] == 'stalled':
                control.ok_dialog(heading, "No Seeders Found")
                break
            f_body = (f"Progress: {torrent['progress'] * 100} %[CR]"
                      f"Seeders: {torrent['seeds']}[CR]"
                      f"Speed: {source_utils.get_size(torrent['download_speed'])}")
            control.progressDialog.update(int(torrent['progress']), f_body)
        del monitor
        control.progressDialog.close()
        if torrent['download_finished']:
            control.ok_dialog(heading, f"{torrent['name']} has been added to your Torbox")
        else:
            self.delete_torrent(torrent_id)