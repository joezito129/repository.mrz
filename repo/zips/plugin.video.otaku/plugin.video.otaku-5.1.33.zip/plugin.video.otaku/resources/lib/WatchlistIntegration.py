import pickle

from resources.lib.ui import control, database, utils
from resources.lib.ui.router import Route
from resources.lib.WatchlistFlavor import WatchlistFlavor
from resources.lib import OtakuBrowser

BROWSER = OtakuBrowser.BROWSER


def get_auth_dialog(flavor: str) -> bool:
    from resources.lib.windows import wlf_auth
    window = wlf_auth.WatchlistFlavorAuth(f"wlf_auth_{flavor}.xml", control.ADDON_PATH, flavor=flavor)
    auth = window.doModal()
    del window
    return auth


@Route('watchlist_login/*')
def WL_LOGIN(payload: str, params: dict) -> None:
    auth_dialog = params.get('auth_dialog')
    auth = True if auth_dialog is None else get_auth_dialog(payload)
    if auth:
        WatchlistFlavor.login_request(payload)
    control.exit_code()


@Route('watchlist_logout/*')
def WL_LOGOUT(payload: str, params: dict) -> None:
    WatchlistFlavor.logout_request(payload)
    control.exit_code()


@Route('watchlist/*')
def WATCHLIST(payload: str, params: dict) -> None:
    watchlist_page = WatchlistFlavor.watchlist_request(payload)
    control.draw_items(watchlist_page, 'addons')

    if watchlist_page:
        url, flavor, status = watchlist_page[0]['url'].split("/", 2)
        next_up = False
        statuses = WatchlistFlavor.watchlist_action_statuses(flavor)
        for x, status in statuses:
            if status == "watching":
                database.background_cache(WatchlistFlavor.watchlist_status_request, 60, flavor, status, next_up)


@Route('watchlist_status_type/*')
def WATCHLIST_STATUS_TYPE(payload: str, params: dict) -> None:
    flavor, status = payload.split("/", 1)
    next_up = params.get('next_up')
    content_type = 'tvshows' if next_up is None else 'videos'
    control.draw_items(database.cache(WatchlistFlavor.watchlist_status_request, 60, False, flavor, status, next_up), content_type)


@Route('watchlist_status_type_pages/*')
def WATCHLIST_STATUS_TYPE_PAGES(payload: str, params: dict) -> None:
    flavor, status, offset = payload.split("/", 2)
    page = int(params.get('page', 1))
    next_up = params.get('next_up')
    content_type = 'tvshows' if next_up is None else 'videos'
    control.draw_items(database.cache(WatchlistFlavor.watchlist_status_request, 60, False, flavor, status, next_up, offset, page), content_type)


@Route('watchlist_to_ep/*')
def WATCHLIST_TO_EP(payload: str, params: dict) -> None:
    payload_list = payload.split("/", 1)
    mal_id = int(payload_list[0])
    eps_watched = int(payload_list[1])

    if (show := database.get_show(mal_id)) is None:
        show = BROWSER.get_anime(mal_id)
    kodi_meta = pickle.loads(show['kodi_meta'])
    kodi_meta['eps_watched'] = eps_watched
    database.update_kodi_meta(mal_id, kodi_meta)
    control.draw_items(*database.cache(OtakuBrowser.get_anime_init, 60, False, mal_id))


@Route('watchlist_manager/*')
def CONTEXT_MENU(payload: str, params: dict) -> None:
    if not control.getBool('watchlist.update.enabled'):
        control.ok_dialog(control.ADDON_NAME, 'No Watchlist Enabled: \n\nPlease enable [B]Update Watchlist[/B] before using the Watchlist Manager')
        control.exit_code()
        return None

    payload_list = payload.split("/", 2)
    # path = int(payload_list[0])
    mal_id = int(payload_list[1])
    # eps_watched = int(payload_list[2])

    if (show := database.get_show(mal_id)) is None:
        show = BROWSER.get_anime(mal_id)

    if (flavor := WatchlistFlavor.get_update_flavor()) is None:
        control.ok_dialog(control.ADDON_NAME, 'No Watchlist Enabled: \n\nPlease Enable a Watchlist before using the Watchlist Manager')
        control.exit_code()
        return None

    actions = WatchlistFlavor.context_statuses()

    kodi_meta = pickle.loads(show['kodi_meta'])
    title = kodi_meta['title_userPreferred']

    context = control.select_dialog(f"{title}  {control.colorstr(f'({str(flavor.flavor_name).capitalize()})', 'blue')}", list(map(lambda x: x[0], actions)))
    if context != -1:
        heading = f'{control.ADDON_NAME} - ({str(flavor.flavor_name).capitalize()})'
        status = actions[context][1]
        if status == 'DELETE':
            yesno = control.yesno_dialog(heading, f'Are you sure you want to delete [I]{title}[/I] from [B]{flavor.flavor_name}[/B]\n\nPress YES to Continue:')
            if yesno:
                delete = delete_watchlist_anime(mal_id)
                if delete:
                    control.ok_dialog(heading, f'[I]{title}[/I] was deleted from [B]{flavor.flavor_name}[/B]')
                else:
                    control.ok_dialog(heading, 'Unable to delete from Watchlist')
        elif status == 'set_score':
            score_list = [
                "(10) Masterpiece",
                "(9) Great",
                "(8) Very Good",
                "(7) Good",
                "(6) Fine",
                "(5) Average",
                "(4) Bad",
                "(3) Very Bad",
                "(2) Horrible",
                "(1) Appalling",
                "(0) No Score"
            ]
            score = control.select_dialog(f'{title}: ({str(flavor.flavor_name).capitalize()})', score_list)
            if score != -1:
                score = 10 - score
                set_score = set_watchlist_score(mal_id, score)
                if set_score:
                    control.ok_dialog(heading, f'[I]{title}[/I]   was set to [B]{score}[/B]')
                else:
                    control.ok_dialog(heading, 'Unable to Set Score')
        else:
            set_status = set_watchlist_status(mal_id, status)
            if set_status == 'watching':
                control.ok_dialog(heading, 'This show is still airing, so we\'re keeping it in your "Watching" list and marked all aired episodes as watched.')
            elif set_status:
                control.ok_dialog(heading, f'[I]{title}[/I]  was added to [B]{status}[/B]')
            else:
                control.ok_dialog(heading, 'Unable to Set Watchlist')
    control.exit_code()
    return None


def add_watchlists(items: list) -> list:
    if (flavors := WatchlistFlavor.get_enabled_watchlists()) is not None:
        for flavor in flavors:
            item = utils.allocate_item(f"{flavor.username}'s {flavor.title}", f"watchlist/{flavor.flavor_name}", True, False, [], flavor.image, {})
            items.append(item)
    return items


def watchlist_update_episode(mal_id: int, episode: int):
    if WatchlistFlavor.get_update_flavor() is not None:
        return WatchlistFlavor.watchlist_update_episode(mal_id, episode)
    return None


def set_watchlist_status(mal_id: int, status: str):
    if WatchlistFlavor.get_update_flavor() is not None:
        return WatchlistFlavor.watchlist_set_status(mal_id, status)
    return None


def set_watchlist_score(mal_id: int, score: int):
    if WatchlistFlavor.get_update_flavor() is not None:
        return WatchlistFlavor.watchlist_set_score(mal_id, score)
    return None


def delete_watchlist_anime(mal_id: int):
    if WatchlistFlavor.get_update_flavor() is not None:
        return WatchlistFlavor.watchlist_delete_anime(mal_id)
    return None
