import xbmc

from resources.lib.ui import control
from resources.lib.windows.base_window import BaseWindow


class PlayingNext(BaseWindow):
    def __init__(self, xml_file, xml_location, *args, actionArgs=None):
        super().__init__(xml_file, xml_location, actionArgs=actionArgs)
        self.player = xbmc.Player()
        self.playing_file = self.player.getPlayingFile()
        self.closed = False
        self.actioned = False
        self.total_time = self.player.getTotalTime()
        self.duration = self.total_time - self.player.getTime()
        self.skipoutro_end = actionArgs['skipoutro_end']

    def onInit(self):
        self.background_tasks()

    def background_tasks(self):
        progress_bar = self.getControl(3014)
        while not self.closed and self.player.isPlayingVideo() and self.playing_file == self.player.getPlayingFile():
            if progress_bar:
                percent = (self.total_time - self.player.getTime()) / self.duration * 100
                if percent < 2:
                    break
                progress_bar.setPercent(percent)
            xbmc.sleep(1000)
        self.close()

    def close(self):
        self.closed = True
        super(PlayingNext, self).close()

    def onClick(self, controlID):
        self.handle_action(controlID)

    def handle_action(self, controlID):
        if controlID == 3001:   # playnext
            self.actioned = True
            self.player.playnext()
            self.close()
        elif controlID == 3002:   # close
            self.actioned = True
            self.close()
        elif controlID == 3003:   # skipoutro
            self.actioned = True
            current_chapter = xbmc.getInfoLabel('Player.ChapterName').lower()
            if any(x in current_chapter for x in control.outro_keywords):
                xbmc.executebuiltin("Action(ChapterOrBigStepForward)")
            else:
                skipoutro_end_skip_time = self.skipoutro_end
                if skipoutro_end_skip_time != 0:
                    self.player.seekTime(skipoutro_end_skip_time)
            self.close()

    def onAction(self, action):
        actionID = action.getId()
        if actionID in [92, 10]:
            # BACKSPACE / ESCAPE
            self.close()
