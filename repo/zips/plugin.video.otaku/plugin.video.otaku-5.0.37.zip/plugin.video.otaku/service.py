from resources.lib.ui import maintenance

maintenance.run_maintenance()
